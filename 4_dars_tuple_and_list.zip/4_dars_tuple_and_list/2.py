# sonlar = (input("Probel bilan kiriting: ")).split(" ")

# for i in range(len(sonlar)):
#     sonlar[i] = int(sonlar[i])    
# sonlar = [3, 5, 6, 34, 78, 33,23]
# raqam = 3
# for son in sonlar:
#     a = son
#     while son!=0:
#         if son % 10!=raqam:
#             break
#         son //=10
#     else:
#         print(a)


# Uyga vazifa 
# 1 masala
# lst = [1, 2, 33, 5, 6, 7, 7]
# son = (input("Son kiriting: "))

# for i in range(len(lst)):
#     for j in range(i+1,len(lst)):
#         if lst[i] + lst[j] == int(son):
#             print(f"Indekslar {i}, {j}")

# 2 masala
# lst = [1,4,6,8]
# yangi_lst = []
# for i in range(len(lst)):
#     yangi_lst.append(lst[i] * 2)
# print(yangi_lst)

# my_tuple = (10, 20, 30, 40)
# print(my_tuple.index(20))  # Natija: 1
# 3 masala
# lst = (10, 20, 40), (40, 50, 60), (70, 80, 90)
# yangi_lst = [t[:-1] + (100,) for t in lst]
# print(yangi_lst)

# 4 masala
# lst = [(), (), ('',), (), ('a', 'b'), (), ('a', 'b', 'c'), (), ('d',)]
# yangi_lst = []
# for i in lst:
#     if i:
#         yangi_lst.append(i)
# print(yangi_lst)


# 5 masala
# lst = [('item1', '12.20'), ('item2', '15.10'), ('item3', '24.5')]
# lst.sort(key=lambda x: float(x[1]), reverse=True)
# print(lst)

# 6 masala
# matn = input("Matn kiriting: ")
# for i in matn:
#     tple = tuple(matn)
# print(tple)

# 7 masala
# lst = [1, 2, 3, 4]
# prefix = 'emp'
# for i in lst:
#     s = [f"{prefix}{i}"]
#     print(s,end="")

# 8 masala
# matn = "Salom aziz qalaysan".split(" ")
# n = len(matn)
# for i in range(len(matn)):
#     for j in range(0,n-i-1):
#         if len(matn[j])>len(matn[j+1]):
#             matn[j],matn[j+1] = matn[j+1], matn[j]
# print(matn)

# 9 masala
# lst = [12,'salom',4.5,'dunyo',True]
# yangi_lst = []
# a = lst.pop(1)
# b = lst.pop(2)
# yangi_lst.append(b)
# yangi_lst.append(a)
# print(yangi_lst,end=" ")

# 10 masala
# t = (-3, 5, 0, 9, -1, 4)
# musbatlar = []
# for i in range(len(t)):
#     if t[i] > 0:
#         musbatlar.append(t[i])
# print(tuple(musbatlar))

# 11 masala
# lst = ['salom', 23, 'dunyo', 5, 100, 'python']
# yangi_matn = []
# yangi_raqam = []
# for i in lst:
#     if type(i) == str:
#         yangi_matn.append([i])
#     elif type(i) == int:
#         yangi_raqam.append([i])

# yangi_matn.sort()
# yangi_raqam.sort(reverse=True)
# print(yangi_matn)
# print(yangi_raqam)

# 12 masala
# lst = [(3, 10), (1, 20), (2, 30)]
# lst.sort(key=lambda i: int(i[0]),reverse=False)
# print(lst)

# 13 masala
# lst = [1, 2, 3, 4]
# yangi_lst = []
# for i in lst:
#     yangi_lst.append(i**2)
# print(yangi_lst)

# 14 masala
# lst = ['salom', 'dunyo', 'python']
# matn = str(lst).title()
# print(matn)

# 15 masala
# tple = (1,2,3,4,5)
# y = 0
# for i in tple:
#     y+=i
# print(y)